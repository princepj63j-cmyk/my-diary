Instagram Diary

This is a polished front-end diary.

To make all your friends see the same pages:
1. Create a Firebase Firestore project.
2. Replace localStorage in script.js with Firestore reads/writes.
3. Host on GitHub Pages or Netlify.

Everything else (UI, animations, page navigation) is ready.
