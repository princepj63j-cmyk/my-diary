let pages=JSON.parse(localStorage.getItem('diary')||'null')||[
{name:'Welcome',msg:'Welcome to our diary.\nLeave a page for me ❤️',date:new Date().toLocaleDateString()}
];
let i=0;
function openBook(){cover.classList.add('hidden');book.classList.remove('hidden');show();}
function show(){
let p=pages[i];
page.innerHTML=`<h2>Page ${i+1}</h2><hr><strong>${p.name}</strong><p>${p.msg}</p><small>${p.date}</small>`;
count.textContent=`${i+1}/${pages.length}`;
}
function next(){if(i<pages.length-1){i++;show();}}
function prev(){if(i>0){i--;show();}}
function add(){
let m=msg.value.trim(); if(!m){alert('Write something');return;}
pages.push({name:name.value||'Anonymous',msg:m,date:new Date().toLocaleString()});
localStorage.setItem('diary',JSON.stringify(pages));
msg.value=''; name.value=''; i=pages.length-1; show();
}